import dis, time

"""
冒泡排序:比较两个相邻的元素,
如果升序的话,
前面的比后面的大,就交换,这样一轮下来,
就会找到这组数据中最大的元素,
然后抛开这个元素继续重复上述步骤.直到排完为止.
"""


def BubbleSort(nums):
    for i in range(len(nums) - 1):
        for j in range(len(nums) - i - 1):
            if nums[j] > nums[j + 1]:
                nums[j], nums[j + 1] = nums[j + 1], nums[j]


"""
快速排序：任取待排序中的某一元素作为基准值,按照该排序码,
将待排序集合分割成两个子序列,
左边的序列比基准值小,
右边的比基准值大.然后对左右子序列重复上述步骤.直到排完为止
"""


def QuickSort(nums, i, j):
    if j - i <= 1:
        return
    beg = i
    end = j
    while i < j:
        while nums[i] < nums[j]:
            j -= 1
        nums[i], nums[j] = nums[j], nums[i]
        while nums[j] > nums[i]:
            i += 1
        nums[i], nums[j] = nums[j], nums[i]
    QuickSort(nums, beg, i)
    QuickSort(nums, i + 1, end)


if __name__ == '__main__':
    listnum = [5, 1, 23, 7, 9, 2, 4, 6, 8, 10, 11, 12, 0, 123]
    print(len(listnum))
    # BubbleSort(listnum)
    print(time.time())
    QuickSort(listnum, 0, len(listnum) - 1)
    print(time.time())
    print(listnum)
    # dis.dis(BubbleSort)
    a = [1, 2, 3, 4]
    for i in range(len(a)-1):
        print(a[i])

