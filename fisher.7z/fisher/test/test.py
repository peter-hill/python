from flask import Flask, current_app, request, Request

# app = Flask(__name__)


# ctx = app.app_context()
# ctx.push()
# a = current_app
# b = current_app.config['DEBUG']
# ctx.pop()

# with app.app_context():
#     a = current_app
#     b = current_app.config['DEBUG']

# 对于实现了上下文协议的对象使用with
# 上下文管理器
# __enter__ __exit__
# 上下文表达式必须要返回一个上下文管理器
# with


# class MyResourse():
#     def __enter__(self):
#         print('connect to resourse')
#         return self
#
#     def __exit__(self, exc_type, exc_val, exc_tb):
#         print('close resourse connection')
#         # return True or False
#
#     def query(self):
#         print('query data')


# try :
#     with MyResourse() as resourse:
#         # 1/0
#         resourse.query()
# except Exception as ex:
#     pass