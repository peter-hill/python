"""
author = 'peter'
"""
from app import create_app
"""
启动服务器
"""

app = create_app()  #在app包下初始化文件定义的实例化核心对象

if __name__ == '__main__':
    app.run(host='0.0.0.0', debug=app.config['DEBUG'], port=81)

