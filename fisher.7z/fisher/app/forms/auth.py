from wtforms import Form, StringField, PasswordField
from wtforms.validators import DataRequired, Length


class RegisterForm(Form):
    email = StringField(validators=[DataRequired(message='邮箱不规范'), Length(8, 64)])

    password = PasswordField(validators=[
        DataRequired(message='密码不能为空'), Length(6, 32)
    ])

    nickname = StringField(validators=[
        DataRequired(message='昵称至少为两个字符'), Length(2, 10)
    ])
