DEBUG = True

SQLALCHEMY_DATABASE_URI = 'mysql+cymysql://root:2132@localhost:3306/garage'
