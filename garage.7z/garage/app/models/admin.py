# from sqlalchemy import Column, Integer, String
#
# from app.models.base import Base
#
#
# class Admin(Base):
#     a_id = Column(Integer, primary_key=True)
#     a_name = Column(String(24), nullable=False)
#     a_password = Column('password', String(128), nullable=True)