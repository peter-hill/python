# from sqlalchemy import Column, Integer, String
#
# from app.models.base import Base
#
#
# class Fittings(Base):
#     f_id = Column(Integer, primary_key=True, autoincrement=True)
#     f_name = Column(String(30))
#     f_brand = Column(String(30))
#     f_number = Column(Integer)
#     f_price = Column(String)
#     pass