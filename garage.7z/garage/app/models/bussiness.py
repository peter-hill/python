# from app.models.base import Base
#
#
# class Bussiness(Base):
#     pass
