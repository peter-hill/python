# from sqlalchemy import Column, Integer
#
# from app.models.base import Base
#
#
# class Car(Base):
#     lp_number = Column(Integer, primary_key=True)
#     pass