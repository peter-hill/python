from flask import request, redirect, url_for, render_template

from app.forms.user import RegisterForm
# from app.models.admin import Admin
from app.models.base import db
from app.models.user import User
from app.web import web


@web.route('/register', methods=['GET', 'POST'])
def register():
    form = RegisterForm(request.form)
    if request.method == 'POST' and form.validate():
        with db.auto_commit():
            user = User()
            # admin = Admin()
            user.set_attrs(form.data)
            db.session.add(user)
            db.session.commit()
        return redirect(url_for('web.register'))

    return render_template('login.html', form=form)


@web.route('/index', methods=['GET', 'POST'])
def index():
    return 'index.html'