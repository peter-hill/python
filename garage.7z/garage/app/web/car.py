from flask import render_template

from . import web


@web.route('/hello')
def hello():
    return render_template()